# MyPyDb



A simple database manager Use it to

[Github-flavored Markdown(https://guides.github.com/features/mastering-markdown/)

create databases, create, update, and delete tables and their records.
